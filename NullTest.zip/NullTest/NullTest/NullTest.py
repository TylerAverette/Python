import tkinter as interface

# When using the place() method, x and a starting pixel on the screen.
# achor declares what section of your item, let's say a button, gets
# attached to that picxel. For instance, if you declare a button with
# x=0m y=o, anchor="nw" then the button will appear in the top left corner, but
# if you change the anchor to "n" half of the button will be off screen, becuase
# the eastern wall of your button will be on point 0.

gui = interface.Tk()
gui.minsize(width = 300, height = 300)
gui.maxsize(width = 1000, height = 1000)

# example of a button centered on the north center
button1 = interface.Button(gui, text = "Center North")
button1.place(x = 150, y = 0, anchor = "n")

# example of half of your button off screen 
button2 = interface.Button(gui, text = "North")
button2.place(x = 0, y = 0, anchor = "n")

# example of a button places in the bottom right corner
button3 = interface.Button(gui, text = "Bottom Right")
button3.place(x = 300, y = 300, anchor = "se")

#example of a button in the center of your screen
button4 = interface.Button(gui, text = "Center")
button4.place(x = 150, y = 150, anchor = "center")

#example of a button in the bottom center of your screen
button4 = interface.Button(gui, text = "Center South")
button4.place(x = 150, y = 300, anchor = "s")

#example of a button in the top right of your screen
button4 = interface.Button(gui, text = "Top Right")
button4.place(x = 300, y = 0, anchor = "ne")

#example of a button in the bottom center of your screen
button5 = interface.Button(gui, text = "Center South")
button5.place(x = 150, y = 300, anchor = "s")

#example of a button in the bottom left of your screen
button6 = interface.Button(gui, text = "Bottom Left")
button6.place(x = 0, y = 300, anchor = "sw")

# Note: You have n,ne,nw,w,s,sw,se,e as options for anchoring.
# Note2: You also have relx and rely that calculate relative to the window size.
#        This is on a scale of 0 being nothing showing to 1 being the entire screen

#example of relativity centered on the first third of the window
button7 = interface.Button(gui, text = "First third")
button7.place(relx = 0.33, rely = 0.33, anchor = "center")

# You will notice the button size does not change as it stretches. This
# is because the button size is not yet set to change relative to the screen
# size.

# let's try to make our button stretch with our screen
button7.place(relwidth = 0.2, relheight = 0.1)

# This will allow the button to get bigger in relation to the size of the screen.

gui.mainloop()

