import pyglet
import resources
from random import randint
from pyglet.window import key, FPSDisplay # This allows you to listen for key presses and Frames per second
from pyglet.sprite import Sprite # Import this so you fon't have to type pyglet.sprite.Sprite each time
from GameObject import GameObject, preload_image

class GameWindow(pyglet.window.Window):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs) # call to let game window initialize
        self.frameRate = 1/60.0  # set framerate
        self.score = 0

        # Customize a label for FPS 
        self.fps_display = FPSDisplay(self)
        self.fps_display.label.font_size = 50
        self.fps_display.label.y = 1030
        self.fps_display.label.x = 1750
        self.fps_display.label.color = 255,255,0, 100

        # Customize score label
        self.scoreLabel = pyglet.text.Label(f"Score: {self.score}",
                          font_name='Times New Roman',
                          font_size=36,
                          x=10, y=10,)

        self.right = False
        self.left = False
        self.player_speed = 600
        self.fire = False
        self.player_fire_rate = 0
        self.cicada_xoffset = 0
        self.cicada_yoffset = 0
        self.ghost_xoffset = 0
        self.ghost_yoffset = 0

        # Create player
        player_sprite = Sprite(preload_image('player.png'))
        self.player = GameObject(500, 0, 1, player_sprite)

        # Create the ship's bullet
        self.player_laser = preload_image('bullet.png')
        self.player_laser_list = []

        # Create background
        self.outerSpace_list = []
        self.outerSpace_img = preload_image('space.png')

        # create initial background array of 2 images
        for i in range(2):
            self.outerSpace_list.append(GameObject(0, i * 1080, None, Sprite(self.outerSpace_img)))

        # Create cicada's
        self.cicada_list = []
        
        for cicada in range(13):
            self.cicada_xoffset = 140 * cicada
            self.cicada_yoffset = 150
            
            self.enemy_cicada = Sprite(preload_image('cicada.png'))
            self.cicada_list.append(GameObject(0 + self.cicada_xoffset, 450 + self.cicada_yoffset, 2, self.enemy_cicada))

        # Create ghost's
        self.ghost_list = []
        
        for ghost in range(13):
            self.ghost_xoffset = 80 * ghost
            self.ghost_yoffset = 140 
            
            self.enemy_ghost = Sprite(preload_image('ghost.png'))
            self.ghost_list.append(GameObject(50 + self.ghost_xoffset, 350 + self.ghost_yoffset, 1, self.enemy_ghost))

        # Create mothership
        self.mothership_list = []
        mothership_sprite = Sprite(preload_image('mothership.png'))
        self.mothership_list.append(GameObject(750, 750, 50, mothership_sprite))

    def on_key_press(self, symbol, modifiers):
        if symbol == key.RIGHT:
            self.right = True
        if symbol == key.LEFT:
            self.left = True
        if symbol == key.SPACE:
            self.fire = True
            
    def on_key_release(self, symbol, modifiers):
        if symbol == key.RIGHT:
            self.right = False
        if symbol == key.LEFT:
            self.left = False
        if symbol == key.SPACE:
            self.fire = False
    
    def on_draw(self):
        self.clear()

        for space in self.outerSpace_list:
            space.draw()
            
        self.scoreLabel.text = f"Score: {self.score}"    
        self.scoreLabel.draw()
        
        for bullet in self.player_laser_list:
            bullet.draw()

        for enemy in self.cicada_list:
            enemy.draw()
            
        for enemy in self.ghost_list:
            enemy.draw()

        for enemy in self.mothership_list:
            enemy.draw()
            
        self.player.draw()
            
        self.fps_display.draw()

    def update_player(self, dt):
        self.player.update()

        if self.right and self.player.posx < 1920 - self.player.width:
            self.player.posx += self.player_speed * dt

        if self.left and self.player.posx > 0:
            self.player.posx -= self.player_speed * dt

    def update_player_laser(self, dt):
        for bullet in self.player_laser_list:
            bullet.update()
            bullet.posy += 600 * dt

            # If the bullet goes above max y remove it
            if bullet.posy > 1200:
                self.player_laser_list.remove(bullet)

    def player_fire(self, dt):
        self.player_fire_rate -= dt
        
        if self.player_fire_rate <= 0:
            self.player_laser_list.append(GameObject(self.player.posx + 41, self.player.posy + 115, None, Sprite(self.player_laser)))
            self.player_fire_rate += 0.2

    def update_outerSpace(self, dt):
        for space in self.outerSpace_list:
            space.update()
            space.posy -= 100 * dt
            
            if space.posy <= -1080:
                self.outerSpace_list.remove(space)
                self.outerSpace_list.append(GameObject(0, 1080, None, Sprite(self.outerSpace_img)))

    def update_enemy(self, dt):
        for cicada in self.cicada_list:
            cicada.update()
            cicada.posx += 100 * dt

            if cicada.posx >= 1800:
                cicada.posx = 0
                cicada.posy -= 140
                

        for ghost in self.ghost_list:
            ghost.update()
            ghost.posx += 100 * dt

            if ghost.posx >= 1800:
                ghost.posx = 0
                ghost.posy -= 140
                
        for enemy in self.mothership_list:      
            enemy.update()
            enemy.posx += 75 * dt

            if enemy.posx >= 1800:
                enemy.posx = 0
                enemy.posy -= 50

    def collision(self, bullet, target):

        bullet_left = bullet.posx
        bullet_right = bullet.posx + bullet.width
        bullet_center = bullet.posx + (bullet.width/2) 
        bullet_top = bullet.posy

        target_left = target.posx
        target_right = target.posx + target.width
        target_top = target.posy + target.height
        target_bottom = target.posy 

        if bullet_center > target_left and bullet_center < target_right: # check horizontal
            if bullet_top > target_bottom and bullet_top < target_top: # check vertical
                return True
            
        return False

    def detect_hit(self, dt):

        if len(self.player_laser_list) > 0:
    
            #Detection for cicada
            if len(self.cicada_list) > 0:
                for cicada in self.cicada_list:
                    for bullet in self.player_laser_list:
                        cicada.update()
                        bullet.update()
                        if self.collision(bullet, cicada):
                            cicada.hp -= 1
                            self.player_laser_list.remove(bullet)
                            
                            if cicada.hp <= 0:
                                self.cicada_list.remove(cicada)
                                self.score += 200
                                return
                            
            #Detection for ghosts                
            if len(self.ghost_list) > 0:
                for ghost in self.ghost_list:
                    for bullet in self.player_laser_list:
                        ghost.update()
                        bullet.update()
                        if self.collision(bullet, ghost):
                            ghost.hp -= 1
                            self.player_laser_list.remove(bullet)
                            
                            if ghost.hp <= 0:
                                self.ghost_list.remove(ghost)
                                self.score += 100
                                return
                            
            #Detection for mothership
                for bullet in self.player_laser_list:
                    for mothership in self.mothership_list:
                        mothership.update()
                        bullet.update()
                        if self.collision(bullet, mothership):
                            mothership.hp -= 1
                            self.player_laser_list.remove(bullet)
                            print(f"mothership hp: {mothership.hp}")
                            if mothership.hp <= 0:
                                
                                self.score += 1000
                                self.mothership_list.remove(mothership)
                                return
            
    def update(self, dt):
        self.update_player(dt)
        self.detect_hit(dt)
        
        if self.fire:
            self.player_fire(dt)
            
        self.update_player_laser(dt)
        self.update_outerSpace(dt)
        self.update_enemy(dt)
             

if __name__ == "__main__":
    window = GameWindow(1920, 1080, "Space Invaders", resizable = False)
    pyglet.clock.schedule_interval(window.update, window.frameRate)
    pyglet.app.run()

#Notes
    # Pyglet y axis goes from bottom (0) to top (window height)
