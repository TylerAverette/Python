import pyglet
import resources

def preload_image(image):
    img = pyglet.resource.image(image)
    return img

class GameObject:
    def __init__(self, posx, posy, hp, sprite = None):
        self.posx = posx
        self.posy = posy
        self.hp = hp
        if sprite is not None:
            self.sprite = sprite
            
            # This prevents the sprite resetting to the bottom right corner when creating the sprite
            self.sprite.x = self.posx
            self.sprite.y = self.posy
            self.width = self.sprite.width
            self.height = self.sprite.height

    def draw(self):
        self.sprite.draw()

    def update(self):
        
        # Set that sprites new x and y position
        self.sprite.x = self.posx
        self.sprite.y = self.posy
