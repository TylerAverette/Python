import pyglet

pyglet.resource.path = ["resources"]
pyglet.resource.reindex()

player = pyglet.resource.image("player.png")
cicada = pyglet.resource.image("cicada.png")
ghost = pyglet.resource.image("ghost.png")
bullet = pyglet.resource.image("bullet.png")
mothership = pyglet.resource.image("mothership.png")
outerSpace = pyglet.resource.image("space.png")

