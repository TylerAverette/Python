import discord
import os
import random

from discord.ext import commands

client = commands.Bot(command_prefix = ".")

@client.event
async def on_ready():
    # When the bot has all of its information and is ready to go
    print("Bot is ready.")

@client.event
async def on_member_join(member):
    print(f"{member} has joined a server.)")

@client.event
async def on_member_remove(member):
    print(f"{member} has left a server.)")

@client.command()
async def ping(ctx): # The function name is the command name
    await ctx.send(f"Pong! {client.latency * 1000} |ms") # when command is ran, bot will say Pong!

@client.command(aliases = ["8ball", "test"])
async def _8ball(ctx, *, question):
    responses = ["It is certain.",
                 "It is decidedly so.",
                 "without a doubt.",
                 "Yes, definitely.",
                 "You may rely on it.",
                 "As I see it, yes.",
                 "Most liekly.",
                 "Outlook good",
                 "Yes.",
                 "Signs point to yes.",
                 "Reply hazy, try again.",
                 "Ask again later.",
                 "Better not tell you now.",
                 "cannot predict now.",
                 "concentrate and ask again",
                 "Don't count on it",
                 "My reply is no",
                 "My sources say no.",
                 "Outlook not so good.",
                 "Very doubtful."]
    await ctx.send(f'Question: {question}\nAnswer: {random.choice(responses)}')

@client.command()
async def clear(ctx, amount = 5):
    await ctx.channel.purge(limit = amount + 1) # get channel comamand was ran in, limit is amount of messages to delete

@client.command()
async def load(ctx, extension):
    client.load_extension(f'cogs.{extension}')

@client.command()
async def unload(ctx, extension):
    client.unload_extension(f'cogs.{extension}')
    

for filename in os.listdir('./cogs'):
    if filename.endswith('.py'):
        client.load_extension(f'cogs.{filename[:-3]}')
        
client.run("Njg1NTgyNDI2NDcwMDg4ODEy.XmK2gw.hdj-Tcg66mMWqubD8c7njPdsgi0")

