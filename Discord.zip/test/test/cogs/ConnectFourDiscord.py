import discord

from discord.ext import commands

class ConnectFourDiscord(commands.Cog):

    board = [['-'] * 7, ['-'] * 7, ['-'] * 7, ['-'] * 7, ['-'] * 7, ['-'] * 7]
    playerTurn = 1
    winner = ""
    gameOver = False
    
    def __init__(self, client):
        self.client = client # lets you access client from inside of cog

    def drawBoard(self):
        thingToPrint = "```"
        thingToPrint += "\n" + "-" * 17
        
        for row in range(6):
            thingToPrint += f"\n| {self.board[row][0]} "
            for column in range(1, 7):
                thingToPrint += f"{self.board[row][column]} "
                if column == 6:
                    thingToPrint += "|"
        thingToPrint += "\n" + "-" * 17

        if self.winner == "p1":
            thingToPrint += "\n\nPlayer 1 Wins!"
        elif self.winner == "p2":
            thingToPrint += "\n\nPlayer 2 wins!"
                                                                                                                                                                
        thingToPrint += "```"
        
        return thingToPrint

    def checkWinConditions(self):

        # Check for horizontal win case
        for row in range(6):
            for column in range(4):
                if self.board[row][column] == chr(11) and self.board[row][column+1] == chr(11) and self.board[row][column+2] == chr(11) and self.board[row][column+3] == chr(11):
                    self.winner = "p1"
                    self.gameOver = True
                    return
                if self.board[row][column] == chr(169) and self.board[row][column+1] == chr(169) and self.board[row][column+2] == chr(169) and self.board[row][column+3] == chr(169):
                    self.winner = "p2"
                    self.gameOver = True
                    return
                
        # Check for vertical win case
        for row in range(3):
            for column in range(7):
                if self.board[row][column] == chr(11) and self.board[row+1][column] == chr(11) and self.board[row+2][column] == chr(11) and self.board[row+3][column] == chr(11):
                    self.winner = "p1"
                    self.gameOver = True
                    return
                if self.board[row][column] == chr(169) and self.board[row+1][column] == chr(169) and self.board[row+2][column] == chr(169) and self.board[row+3][column] == chr(169):
                    self.winner = "p2"
                    self.gameOver = True
                    return
                
        # check for upward right diagonal
        for row in range(5, 2, -1):
            for column in range(4):
                if self.board[row][column] == chr(11) and self.board[row-1][column+1] == chr(11) and self.board[row-2][column+2] == chr(11) and self.board[row-3][column+3] == chr(11):
                    self.winner = "p1"
                    self.gameOver = True
                    return
                if self.board[row][column] == chr(169) and self.board[row-1][column+1] == chr(169) and self.board[row-2][column+2] == chr(169) and self.board[row-3][column+3] == chr(169):
                    self.winner = "p2"
                    self.gameOver = True
                    return

        # check for upward left diagonal
        for row in range(5, 2, -1):
            for column in range(6, 2, -1):
                if self.board[row][column] == chr(11) and self.board[row-1][column-1] == chr(11) and self.board[row-2][column-2] == chr(11) and self.board[row-3][column-3] == chr(11):
                    self.winner = "p1"
                    self.gameOver = True
                    return
                if self.board[row][column] == chr(169) and self.board[row-1][column-1] == chr(169) and self.board[row-2][column-2] == chr(169) and self.board[row-3][column-3] == chr(169):
                    winner = "p2"
                    gameOver = True
                    return

        # check for downward left diagonal
        for row in range(3):
            for column in range(6, 2, -1):
                if self.board[row][column] == chr(11) and self.board[row-1][column-1] == chr(11) and self.board[row-2][column-2] == chr(11) and self.board[row-3][column-3] == chr(11):
                    self.winner = "p1"
                    self.gameOver = True
                    return
                if self.board[row][column] == chr(169) and self.board[row-1][column-1] == chr(169) and self.board[row-2][column-2] == chr(169) and self.board[row-3][column-3] == chr(169):
                    self.winner = "p2"
                    self.gameOver = True
                    return
                
        # check for downward right diagonal
        for row in range(3):
            for column in range(4):
                if self.board[row][column] == chr(11) and self.board[row-1][column+1] == chr(11) and self.board[row-2][column+2] == chr(11) and self.board[row-3][column+3] == chr(11):
                    self.winner = "p1"
                    self.gameOver = True
                    return
                if self.board[row][column] == chr(169) and self.board[row-1][column+1] == chr(169) and self.board[row-2][column+2] == chr(169) and self.board[row-3][column+3] == chr(169):
                    self.winner = "p2"
                    self.gameOver = True
                    return
    def newGame(self):
        self.board = [['-'] * 7, ['-'] * 7, ['-'] * 7, ['-'] * 7, ['-'] * 7, ['-'] * 7]
        self.playerTurn = 1
        self.winner = ""
        self.gameOver = False
    
    # Events
    @commands.Cog.listener()
    async def on_ready(self):
        print("Bot is ready.")

    # Commands
    @commands.command()
    async def ping2(self, ctx):
        await ctx.send('Pong!')
        
    @commands.command()
    async def connectFour(self, ctx):
        await ctx.send(self.drawBoard())

    @commands.command()
    async def play(self, ctx, *, col):
        if self.gameOver == True:
            await ctx.send("Game is already over, you cannot make another move!")
            return
        
        col = int(col) - 1
        rowPlacement = 5
        for row in range(6):
            if self.board[row][col] != "-":
                rowPlacement = row - 1
                break

        if rowPlacement >= 0:
            if self.playerTurn % 2:
                piece = chr(11)
            else:
                piece = chr(169)
                
            self.board[rowPlacement][col] = piece
            self.playerTurn += 1
            self.checkWinConditions()
            await ctx.send(self.drawBoard())

            if self.gameOver == True:
                self.newGame()
                
        else:
            await ctx.send("Invalid column, try again, use your brain this time!")

    @commands.command()
    async def resetGame(self, ctx):
        self.board = [['-'] * 7, ['-'] * 7, ['-'] * 7, ['-'] * 7, ['-'] * 7, ['-'] * 7]
        self.playerTurn = 1
        self.winner = ""
        self.gameOver = False

        await ctx.send(self.drawBoard())
            
def setup(client):
        client.add_cog(ConnectFourDiscord(client))
