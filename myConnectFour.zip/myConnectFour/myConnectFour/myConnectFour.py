from tkinter import *

class Piece():

    x = 0
    y = 0
    color = "green"

    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color

class Model():

    playerWinCount = 0
    computerWinCount = 0
    gameOver = False

    def __init__(self):
        self.playerTurn = 1
        self.data = [[Piece]* 8, [Piece]* 8, [Piece]* 8, [Piece]* 8, [Piece]* 8, [Piece]* 8, [Piece]* 8, [Piece]* 8]

    def play(self, row, column):
        self.playerTurn += 1

class ConnectFour():

    borderSize = 6
    zoneWidth = 80
    zoneHeight = 80
    canvasWidth = 8 * zoneWidth + borderSize
    canvasHeight = 8 * zoneHeight + borderSize


    def __init__(self):

        self.model = Model()

        # create window
        root = Tk()
        root.title("Connect Four by Christopher Tyler Averette")
        root.geometry()

        # create Canvas
        canvas = Canvas(root, height = self.canvasHeight, width = self.canvasWidth)
        canvas.pack()

        # create click event for canvas
        canvas.bind("<Button-1>", self.click)
        
        # draw canvas
        self.canvas = canvas
        self.drawBoard()
        
        root.mainloop()

    def click(self, clicked):
        x = clicked.x
        y = clicked.y

        if self.model.gameOver == True:
            self.endGame()
            return

        row = -1   # out of bounds row
        column = x // self.zoneWidth
        
        # loop through all rows in the column that corresponds to the click
        for rows in range(7, -1, -1):
            if self.model.data[rows][column].color == "green": # Find the first column with a piece player by a player, and place piece above it
                row = rows
                break

        # This sets cap to make sure the program stays in bounds
        if row >= 0:
            self.model.play(row,column)
            self.makeMove(column)
           
            self.canvas.create_oval(x - 5, y - 5, x + 5, y + 5, fill = "blue")

    def drawBoard(self):

        for row in range(8):
            y = row * self.zoneHeight + self.borderSize
            for column in range(8):
                x = column * self.zoneWidth + self.borderSize
                self.canvas.create_rectangle(x,y,x + self.zoneHeight, y + self.zoneWidth,
                                       fill = "orange", outline = "gold", width = self.borderSize)   

    def makeMove(self, column):
        rowPlacement = -1

        # grab the row available in the column we clicked on
        for row in range(7, -1, -1):
            if self.model.data[row][column].color == "green": # if nobody has played here
                #row placement is a placeholder to say what type of piece goes in that slot
                rowPlacement = row 
                break

        if self.model.playerTurn % 2:
            color = "red"
        else:
            color = "blue"

        if row >= 0:
            y = rowPlacement * self.zoneHeight + self.borderSize
            x = column * self.zoneHeight + self.borderSize
                    
            piece = Piece(x, y, color)
            self.model.data[rowPlacement][column] = piece # overwrite placeHolder with piece class

            dataAccess = self.model.data[rowPlacement][column]  
            self.canvas.create_oval(dataAccess.x,dataAccess.y,dataAccess.x + self.zoneHeight, dataAccess.y + self.zoneWidth,
                                            fill = dataAccess.color, outline = "black", width = self.borderSize)
        self.checkWinConditions()
    
    def checkWinConditions(self):
        readData = self.model.data

        # check for horizontal win case
        for row in range(8):
            for column in range(5):                
                # player win
                if readData[row][column].color == "blue" and readData[row][column + 1].color == "blue" and readData[row][column + 2].color == "blue" and readData[row][column + 3].color == "blue":
                    self.model.playerWinCount += 1
                    print("Player Wins Horizontal")
                    self.model.gameOver = True
                    return

                # computer win
                if readData[row][column].color == "red" and readData[row][column + 1].color == "red" and readData[row][column + 2].color == "red" and readData[row][column + 3].color == "red":
                    self.model.computerWinCount += 1
                    print("Computer Wins Horizontal")
                    self.model.gameOver = True
                    return

        # check for vertical win
        for row in range(5):
            for column in range(8):
                # player win
                if readData[row][column].color == "blue" and readData[row + 1][column].color == "blue" and readData[row + 2][column].color == "blue" and readData[row + 3][column].color == "blue":
                    self.model.playerWinCount += 1
                    print("Player Wins Vertical")
                    self.model.gameOver = True
                    return

                # computer win
                if readData[row][column].color == "red" and readData[row + 1][column].color == "red" and readData[row + 2][column].color == "red" and readData[row + 3][column].color == "red":
                    self.model.computerWinCount += 1
                    print("Computer Wins Vertical")
                    self.model.gameOver = True
                    return   

        # check upward right diagonal win
        for row in range(7, 2, -1):
            for column in range(5):
                if readData[row][column].color == "blue" and readData[row - 1][column + 1].color  == "blue" and readData[row - 2][column + 2].color  == "blue" and readData[row - 3][column + 3].color  == "blue":
                    self.model.playerWinCount += 1
                    print("Player Wins Upward right Diagonal")
                    self.model.gameOver = True
                    return

                if readData[row][column].color == "red" and readData[row - 1][column + 1].color  == "red" and readData[row - 2][column + 2].color  == "red" and readData[row - 3][column + 3].color  == "red":
                    self.model.computerWinCount += 1
                    print("Computer Wins Upward right Diagonal")
                    self.model.gameOver = True
                    return

        # check for upward left diagonal
        for row in range(7, 2, -1):
            for column in range(7, 2 , -1):
                if readData[row][column].color == "blue" and readData[row - 1][column - 1].color  == "blue" and readData[row - 2][column - 2].color  == "blue" and readData[row - 3][column - 3].color  == "blue":
                    self.model.playerWinCount += 1
                    print("Player Wins Upward left Diagonal")
                    self.model.gameOver = True
                    return

                if readData[row][column].color == "red" and readData[row - 1][column - 1].color  == "red" and readData[row - 2][column - 2].color  == "red" and readData[row - 3][column - 3].color  == "red":
                    self.model.computerWinCount += 1
                    print("Computer Wins Upward left Diagonal")
                    self.model.gameOver = True
                    return

        # check for downward left diagonal
        for row in range(5):
            for column in range(7, 2, -1):
                if readData[row][column].color == "blue" and readData[row + 1][column - 1].color  == "blue" and readData[row + 2][column - 2].color  == "blue" and readData[row + 3][column - 3].color  == "blue":
                    self.model.playerWinCount += 1
                    print("Player Wins downward left Diagonal")
                    self.model.gameOver = True
                    return

                if readData[row][column].color == "red" and readData[row + 1][column - 1].color  == "red" and readData[row + 2][column - 2].color  == "red" and readData[row + 3][column - 3].color  == "red":
                    self.model.computerWinCount += 1
                    print("Computer Wins downward left Diagonal")
                    self.model.gameOver = True
                    return

        # check for downward right diagonal
        for row in range(5):
            for column in range(5):
                if readData[row][column].color == "blue" and readData[row + 1][column + 1].color  == "blue" and readData[row + 2][column + 2].color  == "blue" and readData[row + 3][column + 3].color  == "blue":
                    self.model.playerWinCount += 1
                    print("Player Wins downward right Diagonal")
                    self.model.gameOver = True
                    return

                if readData[row][column].color == "red" and readData[row + 1][column + 1].color  == "red" and readData[row + 2][column + 2].color  == "red" and readData[row + 3][column + 3].color  == "red":
                    self.model.computerWinCount += 1
                    print("Computer Wins downward right Diagonal")
                    self.model.gameOver = True
                    return

    def endGame(self):
        self.model.gameOver = False
        self.drawBoard()
        self.model.data = [[Piece]* 8, [Piece]* 8, [Piece]* 8, [Piece]* 8, [Piece]* 8, [Piece]* 8, [Piece]* 8, [Piece]* 8]



                
ConnectFour()