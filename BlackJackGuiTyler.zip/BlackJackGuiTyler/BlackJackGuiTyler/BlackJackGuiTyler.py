# christopher Tyler Averette

#Functions

# card class has a value of the card and a filepath for its image
# player class has a value for the player's hand handValue and current state of stand
# dealer class has a value for the dealer's hand and handValue
# create Deck takes not variables and creates a deck from our card list
# printDeck(deck) takes a deck variable of type list and prints it
# createHand adds returns two random cards
# handValue takes a hand and an identifier 0 for dealer and 1 for player returns their total value
# checkWinConditions takes a player object and dealer object, then changes a label to show winner
# dealerHit Takes the dealers hand and determine if the dealer should hit
# hitButtonWasPressed takes a player object and dealer object and gives the player another card then checks if dealer should hit
# standButtonWasPressed takes a player object and a dealer object checks to see if dealer should hit once the player has stood
# nextGameButtonPressed clears screem and starts a new game

from tkinter import *
import random

playerIncrement = False
dealerIncrement = False

class gameState:
    def start():
        hitButton["state"] = "normal"
        standButton["state"] = "normal"
        nextGameButton["state"] = "disabled"

class Card:
    def __init__(self, value, filepath):
        self.value = value
        self.filepath = filepath

class Player:
    def __init__(self, hand, handValue, stands):
        self.hand = hand
        self.handValue = handValue
        self.stands = False

class Dealer:
    def __init__(self, hand, handValue):
        self.hand = hand
        self.handValue = handValue

def createDeck():
    deck = []
    for clubs in range(1,14):
        if clubs > 10 and clubs != 14:
            value = 10
        else:
            value = clubs
        deck.append(Card(value, f"75/clubs-{clubs}-75.png"))
    for hearts in range(1,14):
        if hearts > 10 and hearts != 14:
            value2 = 10
        else:
            value2 = hearts
        deck.append(Card(value2, f"75/hearts-{hearts}-75.png"))
    for diamonds in range(1,14):
        if diamonds > 10 and diamonds != 14:
            value3 = 10
        else:
            value3 = diamonds
        deck.append(Card(value3, f"75/diamonds-{diamonds}-75.png"))
    for spades in range(1,14):
        if spades > 10 and spades != 14:
            value4 = 10
        else:
            value4 = spades
        deck.append(Card(value4, f"75/spades-{spades}-75.png"))
    return deck

def printDeck(deck):
    print(len(deck))
    for i,val in enumerate(deck):
        print(deck[i].filepath)
        print(deck[i].value)

def createHand():
    global deck

    hand = []
    deckLength = len(deck)

    firstCard = random.random()
    firstCardAsInt = int(firstCard * deckLength)
    hand.append(deck[firstCardAsInt])
    deck.pop(firstCardAsInt)
    deckLength = len(deck)

    secondCard = random.random()
    secondCardAsInt = int(secondCard * deckLength)
    hand.append(deck[secondCardAsInt])
    deck.pop(secondCardAsInt)

    return hand

def handValue(hand, handType):
    # handType defines whether it is the dealer or players hand dealer = 0 player = 1
    global playerIncrement
    global dealerIncrement

    sum = 0
    hasAce = False
    for i, val in enumerate(hand):
        if hand[i].value == 1:
            hasAce = True
        sum += hand[i].value
    if sum < 12 and hasAce == True:
        sum += 10
        increment = True
    elif sum > 21 and handType == 0 and playerIncrement == True:
        playerIncrement = False
        sum -= 10
    elif sum > 21 and handType == 1 and dealerIncrement == True:
        dealerIncrement = False
        sum -= 10
    return sum

def checkWinConditions():

    global player1
    global dealer

    gameOver = False

    # Check for Bust

    if player1.handValue > 21:
        gameResultLabel.configure(text = "Dealer Wins!: Player Busted")
        gameOver = True
    
    if dealer.handValue > 21 and gameOver == False:
        gameResultLabel.configure(text = "Player Wins!: Dealer Busted")
        gameOver = True

    # check for 5 card charlie
    if len(player1.hand) > 4 and gameOver == False:
        gameResultLabel.configure(text = "5 Card Charlie: Player Wins!")
        gameOver = True

    if len(dealer.hand) > 4 and gameOver == False:
        gameResultLabel.configure(text = "5 Card Charlie: Dealer Wins!")
        gameOver = True

    # Dealer Wins
    if dealer.handValue == 21 and gameOver == False:
        gameResultLabel.configure(text = "Dealer Wins!: BlackJack")
        gameOver = True
    if player1.stands:
        if dealer.handValue == player1.handValue and gameOver == False:
            gameResultLabel.configure(text = "Dealer Wins!: Tie Game")
            gameOver = True
        elif dealer.handValue > player1.handValue and gameOver == False:
            gameResultLabel.configure(text = "Dealer Wins!: Higher Total")
            gameOver = True
    
    # Player Wins
    if player1.handValue == 21 and gameOver == False:
        gameResultLabel.configure(text = "Player Wins!: BlackJack")
        gameOver = True
    elif player1.handValue > dealer.handValue and player1.stands == True and gameOver == False:
        gameResultLabel.configure(text = "Player Wins!: Higher Total")
        gameOver = True

    # check if games if over
    if gameOver:
        hitButton["state"] = "disabled"
        standButton["state"] = "disabled"
        nextGameButton["state"] = "normal"

    return
        
def dealerHit():

    global deck
    global dealer

    if dealer.handValue < 17:
        card = random.random()
        cardAsInt = int(card * len(deck) + 1)
        dealer.hand.append(deck[cardAsInt])
        deck.pop(cardAsInt)

        dealer.handValue = handValue(dealer.hand, 0)

        if len(dealer.hand) == 3:
            dealerThirdCardImg = PhotoImage(file=f"{dealer.hand[2].filepath}")
            dealerHandValueLabel.configure(text = f"Value: {dealer.handValue}")
            dealerHandCountLabel.configure(text = f"dealer Hand Count: {len(dealer.hand)}")
            dealerThirdCardLabel.configure(image = dealerThirdCardImg)
            checkWinConditions()
            root.mainloop()
            return
        elif len(dealer.hand) == 4:
            dealerFourthCardImg = PhotoImage(file=f"{dealer.hand[3].filepath}")
            dealerHandValueLabel.configure(text = f"Value: {dealer.handValue}")
            dealerHandCountLabel.configure(text = f"dealer Hand Count: {len(dealer.hand)}")
            dealerFourthCardLabel.configure(image = dealerFourthCardImg)
            checkWinConditions()
            root.mainloop()
            return
        elif len(dealer.hand) == 5:
            dealerFifthCardImg = PhotoImage(file=f"{dealer.hand[4].filepath}")
            dealerHandValueLabel.configure(text = f"Value: {dealer.handValue}")
            dealerHandCountLabel.configure(text = f"dealer Hand Count: {len(dealer.hand)}")
            dealerFifthCardLabel.configure(text = playerFifthCardImg)
            hitButton["state"] = "disabled"
            checkWinConditions()
            root.mainloop()
            return
    return

def hitButtonWasPressed():

    global deck
    global player1
    global dealer
    
    card = random.random()
    cardAsInt = int(card * len(deck) + 1)
    player1.hand.append(deck[cardAsInt])
    deck.pop(cardAsInt)

    player1.handValue = handValue(player1.hand, 0)

    if len(player1.hand) == 3:
        playerThirdCardImg = PhotoImage(file=f"{player1.hand[2].filepath}")
        playerHandValueLabel.configure(text = f"Value: {player1.handValue}")
        playerHandCountLabel.configure(text = f"Player Hand Count: {len(player1.hand)}")
        playerThirdCardLabel.configure(image = playerThirdCardImg)

        if player1.handValue >= 21:
            player1.stands = True
            hitButton["state"] = "disabled"
            checkWinConditions()

        if dealer.handValue < 17 and player1.handValue < 22:
            dealerHit()

        checkWinConditions()

        root.mainloop()
        
    elif len(player1.hand) == 4:
        playerFourthCardImg = PhotoImage(file=f"{player1.hand[3].filepath}")
        playerHandValueLabel.configure(text = f"Value: {player1.handValue}")
        playerHandCountLabel.configure(text = f"Player Hand Count: {len(player1.hand)}")
        playerFourthCardLabel.configure(image = playerFourthCardImg)

        if player1.handValue >= 21:
            player1.stands = True
            hitButton["state"] = "disabled"
            checkWinConditions()

        if dealer.handValue < 17 and player1.handValue < 22:
            dealerHit()

        checkWinConditions()

        root.mainloop()
        
    elif len(player1.hand) == 5:
        playerFifthCardImg = PhotoImage(file=f"{player1.hand[4].filepath}")
        playerHandValueLabel.configure(text = f"Value: {player1.handValue}")
        playerHandCountLabel.configure(text = f"Player Hand Count: {len(player1.hand)}")
        playerFifthCardLabel.configure(image = playerFifthCardImg)
        hitButton["state"] = "disabled"

        if player1.handValue >= 21:
            player1.stands = True
            hitButton["state"] = "disabled"
            checkWinConditions()

        if dealer.handValue < 17 and player1.handValue < 22:
            dealerHit()

        checkWinConditions()

        root.mainloop()
            
def standButtonWasPressed():

    global player1
    global dealer

    hitButton["state"] = "disabled"
    standButton["state"] = "disabled"
    player1.stands = True

    while dealer.handValue < 17 and player1.handValue < 22:
        dealerHit()
        
    checkWinConditions()
     
    return

def nextGameButtonWasPressed():

    global deck
    global gameCount
    global player1
    global dealer

    gameState.start()

    # Initialize Variables
    deck = createDeck()
    discardPile = []
    result = ""

    player1 = Player(createHand(), 0, False)
    player1.handValue = handValue(player1.hand, 0)
    playerScore = 0

    dealer = Dealer(createHand(), 0)
    dealer.handValue = handValue(dealer.hand, 1)

    gameCount += 1

    # Create game labels
    gameCountLabel.configure(text = f"Game #{gameCount}")

    scoreLabel = Label(root, text = f"Score: #{playerScore}")

    # player Cards GUI
    playerHandCountLabel.configure(text = f"Player Hand Count: {len(player1.hand)}")

    playerHandValueLabel.configure(text = f"Value: {player1.handValue}")

    playerFirstCardImg = PhotoImage(file=f"{player1.hand[0].filepath}")
    playerFirstCardLabel.configure(image = playerFirstCardImg)

    playerSecondCardImg = PhotoImage(file=f"{player1.hand[1].filepath}")
    playerSecondCardLabel.configure(image = playerSecondCardImg)

    # dealer Cards GUI
    dealerHandCountLabel.configure(text = f"Dealer Hand Count: {len(dealer.hand)}")

    dealerHandValueLabel.configure(text = f"Value: {dealer.handValue}")

    dealerFirstCardImg = PhotoImage(file=f"{dealer.hand[0].filepath}")
    dealerFirstCardLabel.configure(image = dealerFirstCardImg)


    dealerSecondCardImg = PhotoImage(file=f"{dealer.hand[1].filepath}")
    dealerSecondCardLabel.configure(image = dealerSecondCardImg)

    gameResultLabel.configure(text = "")

    checkWinConditions()

    if "playerThirdCardLabel" in globals():
        global playerThirdCardLabel
        playerThirdCardLabel.configure(image = "")
    if "playerFourthCardLabel" in globals():
        global playerFourthCardLabel
        playerFourthCardLabel.configure(image = "")
    if "playerFifthCardLabel" in globals():
        global playerFifthCardLabel
        playerFifthCardLabel.configure(image = "")

    if "dealerThirdCardLabel" in globals():
        global dealerThirdCardLabel
        dealerThirdCardLabel.configure(image = "")
    if "playerFourthCardLabel" in globals():
        global dealerFourthCardLabel
        dealerFourthCardLabel.configure(image = "")
    if "dealerFifthCardLabel" in globals():
        global dealerFifthCardLabel
        dealerFifthCardLabel.configure(image = "")


    root.mainloop()


# Initialize Variables
deck = createDeck()
discardPile = []
result = ""

playerHand = createHand()
player1 = Player(createHand(), 0, False)
player1.handValue = handValue(player1.hand, 0)
playerScore = 0

dealer = Dealer(createHand(), 0)
dealer.handValue = handValue(dealer.hand, 1)

gameCount = 1

# Create root
root = Tk()
root.title('BlackJack')
root.minsize(width = 1200, height = 800)
root.maxsize(width = 1920, height = 1080)
root.configure(background = '#161', relief = 'ridge')

# Create game labels
gameCountLabel = Label(root, text = f"Game #{gameCount}")
gameCountLabel.configure(background = '#161')
gameCountLabel.grid(column = 0, row = 0)

scoreLabel = Label(root, text = f"Score: #{playerScore}")
scoreLabel.configure(background = '#161')
scoreLabel.grid(column = 1, row = 0)

# player Cards GUI
playerHandCountLabel = Label(root, text = f"Player Hand Count: {len(player1.hand)}")
playerHandCountLabel.configure(background = '#161')
playerHandCountLabel.grid(column = 0, row = 1)

playerHandValueLabel = Label(root, text = f"Value: {player1.handValue}")
playerHandValueLabel.configure(background = '#161')
playerHandValueLabel.grid(column = 1, row = 1)

playerFirstCardImg = PhotoImage(file=f"{player1.hand[0].filepath}")
playerFirstCardLabel = Label(root, image = playerFirstCardImg)
playerFirstCardLabel.configure(background = '#161')
playerFirstCardLabel.grid(column = 0, row = 2)

playerSecondCardImg = PhotoImage(file=f"{player1.hand[1].filepath}")
playerSecondCardLabel = Label(root, image = playerSecondCardImg)
playerSecondCardLabel.configure(background = '#161')
playerSecondCardLabel.grid(column = 1, row = 2)

playerThirdCardLabel = Label(root)
playerThirdCardLabel.configure(background = '#161')
playerThirdCardLabel.grid(column = 2, row = 2)

playerFourthCardLabel = Label(root)
playerFourthCardLabel.configure(background = '#161')
playerFourthCardLabel.grid(column = 3, row = 2)

playerFifthCardLabel = Label(root)
playerFifthCardLabel.configure(background = '#161')
playerFifthCardLabel.grid(column = 4, row = 2)

# dealer Cards GUI
dealerHandCountLabel = Label(root, text = f"Dealer Hand Count: {len(dealer.hand)}")
dealerHandCountLabel.configure(background = '#161')
dealerHandCountLabel.grid(column = 0, row = 3)

dealerHandValueLabel = Label(root, text = f"Value: {dealer.handValue}")
dealerHandValueLabel.configure(background = '#161')
dealerHandValueLabel.grid(column = 1, row = 3)

dealerFirstCardImg = PhotoImage(file=f"{dealer.hand[0].filepath}")
dealerFirstCardLabel = Label(root, image = dealerFirstCardImg)
dealerFirstCardLabel.configure(background = '#161')
dealerFirstCardLabel.grid(column = 0, row = 4)

dealerSecondCardImg = PhotoImage(file=f"{dealer.hand[1].filepath}")
dealerSecondCardLabel = Label(root, image = dealerSecondCardImg)
dealerSecondCardLabel.configure(background = '#161')
dealerSecondCardLabel.grid(column = 1, row = 4)

dealerThirdCardLabel = Label(root)
dealerThirdCardLabel.configure(background = '#161')
dealerThirdCardLabel.grid(column = 2, row = 4)

dealerFourthCardLabel = Label(root)
dealerFourthCardLabel.configure(background = '#161')
dealerFourthCardLabel.grid(column = 3, row = 4)

dealerFifthCardLabel = Label(root)
dealerFifthCardLabel.configure(background = '#161')
dealerFifthCardLabel.grid(column = 4, row = 4)

# define buttons
hitButton = Button(root, text = "Hit", command = hitButtonWasPressed)
hitButton.configure(background = '#037d50')
hitButton.grid(column = 0, row = 5, sticky = 'nsew')

standButton = Button(root, text = "Stand", command = standButtonWasPressed)
standButton.configure(background = 'red')
standButton.grid(column = 1, row = 5, sticky = 'nsew')

nextGameButton = Button(root, text = "Next Game", command = nextGameButtonWasPressed)
nextGameButton.config(background = 'yellow')
nextGameButton.grid(column = 0, row = 6, columnspan = 2, sticky= 'nsew')

gameResultLabel = Label(root, text = f"{result}")
gameResultLabel.configure(background = '#161')
gameResultLabel.grid(column = 0, row = 7, columnspan = 2)

checkWinConditions()

root.mainloop()

# Errors to fix
# 21 case on any game past 1
# hit and stand button don't work on any game past 1 value and count labels are breaking
 # commenting them out allows the card to appear.

