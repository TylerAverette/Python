import tkinter

def prints():
    print("button was pressed")

root = tkinter.Tk()

buttonFrame = tkinter.Frame(root, borderwidth = 2, relief='ridge')
buttonFrame.grid(column = 0, row = 0, sticky = "nsew")

button = tkinter.Button(buttonFrame, text = "Button", command = prints)

button.pack(fill='x')

root.mainloop()