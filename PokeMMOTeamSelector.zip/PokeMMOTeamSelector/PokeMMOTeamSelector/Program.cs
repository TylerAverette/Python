﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Net.Http.Headers;
using System.Security.Cryptography;

namespace PokeMMOTeamSelector
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> trainerNames = new List<string>() { "Jaylon", "Cole", "Justin", "Tyler", "Ultra" };
            List<Trainer> trainers = new List<Trainer>();

            
            foreach (var name in trainerNames)
            {
                Trainer x = new Trainer(name);
                //EliminateDuplicates(trainers);
                trainers.Add(x);
            }
            PrintAllTrainers(trainers);

            void PrintAllTrainers(List<Trainer> trainers)
            {
                foreach (var trainer in trainers)
                {
                    trainer.PrintTrainer();
                }
            }
        }

        //public void EliminateDuplicates(List<Trainer> trainers)
        //{
            
        //}

        //public int Re_roll()
        //{
        //    var randomPokemon = 0;
        //    Random rand = new Random();

        //    randomPokemon = rand.Next(1, 643);

        //    if (randomPokemon != index)
        //    {
        //        this.pokemon[index] = randomPokemon;
        //    }
        //}

        
    }
}
