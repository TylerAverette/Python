﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace PokeMMOTeamSelector
{
    class Trainer
    {
        string name;
        public List<int> pokemon;
        List<int> takenPokemon;

        public Trainer()
        {
            this.name = "";
            this.pokemon = new List<int>();
            this.takenPokemon = new List<int>();
            this.GetPokemon();
        }

        public Trainer(string n)
        {
            this.name = n;
            this.pokemon = new List<int>();
            for (int i = 0; i < 5; i++)
            {
                this.GetPokemon();
            }
        }

        public void GetPokemon()
        {
            var randomPokemon = 0;
            Random rand = new Random();

            randomPokemon = rand.Next(1, 643);

            if (this.pokemon.Count < 1 || randomPokemon != this.pokemon[pokemon.Count - 1]) 
            {
                this.pokemon.Add(randomPokemon);
            }
            else
            {
                this.GetPokemon();
            }
            
        }

        public void PrintTrainer() {
            Console.WriteLine("Name: {0}", this.name);
            int counter = 0;

            foreach (var pokemon in pokemon)
            {
                Console.WriteLine("Pokemon {0}: Pokedex#{1}", counter, this.pokemon[counter]);
                counter++;
            }
            Console.WriteLine();
        }
    }
}