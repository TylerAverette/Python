import random
playerIncrement = False
dealerIncrement = False

def getCard():
    card = random.random()
    return int(card * 13 + 1)

def value(card):
    if card < 11:
        return card
    else:
        return 10

def name(card):
    names = "Joker Ace Two Three Four Five Six Seven Eight Nine Ten Jack Queen King".split()
    return names[card]

def hasAce(hand):
    for card in hand:
        if card == 1:
            return True
    return False

def softSum(hand, handType):
    global dealerIncrement 
    global playerIncrement 

    sum = 0
    for card in hand:
        card = value(card)
        if card == 1 and playerIncrement == True:
            card += 10
        sum += card
    if sum < 12:
        if handType == 0:
            dealerIncrement = True
        if handType == 1:
            playerIncrement = True
        sum += 10
    elif sum > 21 and handType == 0 and dealerIncrement == True:
        dealerIncrement = False
        sum -= 10
    elif sum > 21 and handType == 1 and playerIncrement == True:
        sum -= 10
        playerIncrement = False
        
    return sum 

def sum(hand):
    sum = 0
    for card in hand:
        sum += value(card)
    return sum

def handValue(hand, points, handType):
    if hasAce(hand) == True:
        return softSum(hand, handType)
    else:
        return sum(hand)

def handNames(hand):
    names = ""
    for card in hand:
        cardName = name(card)
        names += cardName + " "
    return names

def dealerHit(dealerHand, dealerHandNames, dealerPoints):
    print("\nDealer Hits!")
    newCard = getCard()
    dealerHand.append(newCard)
    dealerHandNames = handNames(dealerHand)
    dealerPoints = handValue(dealerHand, dealerPoints, 0)

    return (dealerHand, dealerHandNames, dealerPoints)

def playerHit(playerHand, playerHandNames, playerPoints):
    print("\nPlayer Hits!")
    newCard = getCard()
    playerHand.append(newCard)
    playerHandNames = handNames(playerHand)
    playerPoints = handValue(playerHand, playerPoints, 1)

    return (playerHand, playerHandNames, playerPoints)

def printRound(playerHandNames,playerPoints, dealerHandNames, dealerPoints):
    print("")
    print(f"Player Hand: {playerHandNames}")
    print(f"Player Points: {playerPoints}")
    print(f"Dealer Hand: {dealerHandNames}")
    print(f"Dealer Points: {dealerPoints}")
    print("")

def createPlayer(playerHand, playerHandNames, playerPoints):

    playerHand = [getCard(), getCard()]
    playerHandNames = handNames(playerHand)
    
    if hasAce(playerHand):
        playerPoints = softSum(playerHand, 1)
    else:
        playerPoints = sum(playerHand)

    return (playerHand, playerHandNames, playerPoints)

def checkForBust(points):
    if points > 21:
        return True
    return False

def checkForWin(playerPoints, dealerPoints, playerScore, gameOver):

    if len(playerHand) == 5 and playerPoints < 21:
                print("Player Wins! 5 card charlie!")
                playerScore += 10
                gameOver = True

    if playerPoints == dealerPoints:
        print("\nDealer Wins by tie game!")
        playerScore -= 10
        gameOver = True

    if playerPoints > dealerPoints:
        print("\nPlayer Wins by score!")
        playerScore += 10
        gameOver = True

    if dealerPoints > playerPoints:
        print("\nDealer Wins by score!")
        playerScore -= 10
        gameOver = True
    
    return (gameOver, playerScore)

def resetGame(playerHand, playerHandNames, playerPoints, dealerHand, dealerHandNames, dealerPoints, gameOver, gameCount):
    
    print("")
    print(f"Game #{gameCount}")
    print(f"Player Score: {playerScore}")

    playerHand, playerHandNames, playerPoints = createPlayer(playerHand, playerHandNames, playerPoints)
    playerPoints = handValue(playerHand, playerPoints, 1)

    dealerHand, dealerHandNames, dealerPoints = createPlayer(dealerHand, dealerHandNames, dealerPoints)
    dealerPoints = handValue(dealerHand, dealerPoints, 0)

    gameOver = False

    printRound(playerHandNames, playerPoints, dealerHandNames, dealerPoints)

    return(playerHand, playerHandNames, playerPoints, dealerHand, dealerHandNames, dealerPoints, gameOver)


gameCount = 1

print(f"Game #{gameCount}")

# Create a player
playerHand = []
playerHandNames = ""
playerPoints = 0
playerScore = 0


playerHand, playerHandNames, playerPoints = createPlayer(playerHand, playerHandNames, playerPoints)

# Create a dealer
dealerHand = []
dealerHandNames = ""
dealerPoints = 0

dealerHand, dealerHandNames, dealerPoints = createPlayer(dealerHand, dealerHandNames, dealerPoints)

gameOver = False

printRound(playerHandNames, playerPoints, dealerHandNames, dealerPoints)

while gameCount < 10:

    # check for BlackJack
    if playerPoints == 21:
        print(f"Player Wins! Hand Value: {playerPoints}")
        playerScore += 10
        gameOver = True

    if dealerPoints == 21:
        print(f"Player Wins! Hand Value: {dealerPoints}")
        playerScore -= 10
        gameOver = True

    while gameOver == False:

        playerHits = input("\nWould you like to hit? 'Y' for yes or 'N' for no: ")

        while playerHits == 'Y' and len(playerHand) < 5 or playerHits == 'y' and len(playerHand) < 5:
  
            playerHand, playerHandNames, playerPoints = playerHit(playerHand, playerHandNames, playerPoints)
            printRound(playerHandNames, playerPoints, dealerHandNames, dealerPoints)
            gameOver = checkForBust(playerPoints)

            if gameOver == True:
                print(f"Dealer Wins! Player Busted: {playerPoints}")
                playerScore -= 10
                break;
    
            if dealerPoints < 17 and dealerPoints < playerPoints and playerPoints != 21 and len(playerHand) < 5:
                dealerHand, dealerHandNames, dealerPoints = dealerHit(dealerHand, dealerHandNames, dealerPoints)
                printRound(playerHandNames, playerPoints, dealerHandNames, dealerPoints)
                gameOver = checkForBust(dealerPoints)

                if gameOver == True:
                    print(f"Player Wins! Dealer Busted: {dealerPoints}")
                    playerScore += 10
                    break;
            playerHits = ""
            playerHits = input("\nWould you like to hit? 'Y' for yes or 'N' for no: ")

        while dealerPoints < 17 and dealerPoints < playerPoints and playerPoints != 21 and len(playerHand) < 5:
            dealerHand, dealerHandNames, dealerPoints = dealerHit(dealerHand, dealerHandNames, dealerPoints)
            printRound(playerHandNames, playerPoints, dealerHandNames, dealerPoints)
            gameOver = checkForBust(dealerPoints)
            if gameOver == True:
                print(f"Player Wins! Dealer Busted: {dealerPoints}")
                playerScore += 10
        if gameOver == False:
            gameOver, playerScore = checkForWin(playerPoints, dealerPoints, playerScore, gameOver)
                   
    if gameCount < 10:
        gameCount += 1
        playerHand, playerHandNames, playerPoints, dealerHand, dealerHandNames, dealerPoints, gameOver = resetGame(playerHand, playerHandNames, playerPoints, dealerHand, dealerHandNames, dealerPoints, gameOver, gameCount)
        