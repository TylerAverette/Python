import array as arr

n = arr.array('f', [4, 10,22,48])

for x in range(len(n)):
    print("Calculating " + str(n[x]))
    while n[int(x)] != 1:
        if n[int(x)] % 2 == 0:
            n[int(x)] = n[int(x)] /2
        else:
            n[int(x)] = (n[int(x)]*3) + 1
        print(n[x])
    print("")