print("Welcome to the Leap Year tester")
again = "y"

while again == "y" or again == "Y":
    print("Enter a year: ")
    userYear = int(input())
    again = "y"

    if userYear % 4 == 0:
        if userYear % 100 == 0:
            if userYear % 400 == 0:
                print(str((userYear)) + " is a leap year.")
            else:
                print(str((userYear)) + " is not a leap year.")
        else: 
            print(str((userYear)) + " is a leap year.")
    else:
        print(str((userYear)) + " is not a leap year.")

    print("Would you like to try another year? (Enter 'y' for yes, or 'n' for no)")
    again = input()

    if again == "y" or again == "y":
        continue
        
    else:
        break